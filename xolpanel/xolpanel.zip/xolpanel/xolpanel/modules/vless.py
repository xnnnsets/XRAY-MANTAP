from xolpanel import *

@bot.on(events.CallbackQuery(data=b'vless'))
async def vless(event):
    async def vless_(event):
        inline = [
            [Button.inline("[ Trial VLESS ]", "trial-vless")],
            [Button.inline("[ Buat Akun VLESS ]", "add-vless")],
            [Button.inline("[ Hapus VLESS ]", "delete-vless")],
            [Button.inline("[ Cek Login VLESS ]", "login-vless")],
            [Button.inline("[ Tampilkan Semua Akun VLESS ]", "show-vless")],
            [Button.inline("‹ Main Menu ›", "menu")]
        ]
        z = None
        try:
            z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        except requests.exceptions.ConnectionError as e:
            # Tangani kesalahan koneksi
            await event.edit("Failed to retrieve location information")
        msg = f"""
**━━━━━━━━━━━━━━━━**
[ ](https://i.ibb.co/RCf8yW1/Fm5-Mt55-WYAANw9n.jpg)
**⟨ Vless Menu ⟩**
**━━━━━━━━━━━━━━━━**
**» Service:** `VLESS`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"] if z else "N/A"}`
**» Country:** `{z["country"] if z else "N/A"}`
**» 🤖@lihin929**
**━━━━━━━━━━━━━━━━**
"""
        await event.edit(msg, buttons=inline)

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await vless_(event)
    else:
        await event.answer("Asem Lo Ngintip!!", alert=True)

