from xolpanel import *
  
@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
    async def vmess_(event):
        inline = [
            [Button.inline("[ Trial VMESS ]", "trial-vmess")],
            [Button.inline("[ Buat Akun VMESS ]", "add-vmess")],
            [Button.inline("[ Hapus VMESS ]", "delete-vmess")],
            [Button.inline("[ Cek Login VMESS ]", "login-vmess")],
            [Button.inline("[ Tampilkan Semua Akun VMESS ]", "show-vmess")],
            [Button.inline("‹ Main Menu ›", "menu")]
        ]
        z = None
        try:
            z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        except requests.exceptions.ConnectionError as e:
            # Tangani kesalahan koneksi
            await event.edit("Failed to retrieve location information")
        msg = f"""
**━━━━━━━━━━━━━━━━**
[ ](https://i.ibb.co/RCf8yW1/Fm5-Mt55-WYAANw9n.jpg)
**⟨ Vless Menu ⟩**
**━━━━━━━━━━━━━━━━**
**» Service:** `VMESS`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"] if z else "N/A"}`
**» Country:** `{z["country"] if z else "N/A"}`
**» 🤖@lihin929**
**━━━━━━━━━━━━━━━━**
"""
        await event.edit(msg, buttons=inline)

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await vmess_(event)
    else:
        await event.answer("Asem Lo!!", alert=True)
