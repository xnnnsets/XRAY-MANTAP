from xolpanel import *
  
@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan(event):
    async def trojan_(event):
        inline = [
            [Button.inline("[ Trial TROJAN ]", "trial-trojan")],
            [Button.inline("[ Buat Akun TROJAN ]", "add-trojan")],
            [Button.inline("[ Hapus TROJAN ]", "delete-trojan")],
            [Button.inline("[ Cek Login TROJAN ]", "login-trojan")],
            [Button.inline("[ Tampilkan Semua Akun TROJAN ]", "show-trojan")],
            [Button.inline("‹ Main Menu ›", "menu")]
        ]
        z = None
        try:
            z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        except requests.exceptions.ConnectionError as e:
            # Tangani kesalahan koneksi
            await event.edit("Failed to retrieve location information")
        msg = f"""
**━━━━━━━━━━━━━━━━**
[ ](https://i.ibb.co/RCf8yW1/Fm5-Mt55-WYAANw9n.jpg)
**⟨ Vless Menu ⟩**
**━━━━━━━━━━━━━━━━**
**» Service:** `TROJAN`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"] if z else "N/A"}`
**» Country:** `{z["country"] if z else "N/A"}`
**» 🤖@lihin929**
**━━━━━━━━━━━━━━━━**
"""
        await event.edit(msg, buttons=inline)

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await trojan_(event)
    else:
        await event.answer("Gak Punya Akses Lo!!", alert=True)
