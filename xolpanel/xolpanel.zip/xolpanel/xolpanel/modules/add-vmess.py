from xolpanel import *

import base64  # Import modul base64

@bot.on(events.CallbackQuery(data=b'add-vmess'))
async def add_vmess(event):
    async def add_vmess_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Masukan Nama Akun Vmess Lo:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        async with bot.conversation(chat) as bug:
            await event.respond('**Masukan Bug Nya Mas:**')
            bug = bug.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            bug = (await bug).raw_text
        async with bot.conversation(chat) as exp:
            await event.respond("**Anda Mau Membuat Akun Berapa Hari**", buttons=[
                [Button.inline("• 7 Day •", "7")],
                [Button.inline("• 15 Day •", "15")],
                [Button.inline("• 30 Day •", "30")],
                [Button.inline("• Lifetime •", "500")]
            ])
            exp = exp.wait_event(events.CallbackQuery)
            exp_data = (await exp).data.decode("ascii")

        exp_date = None
        if exp_data == "7":
            exp_date = (DT.date.today() + DT.timedelta(days=7)).strftime("%Y-%m-%d")
        elif exp_data == "15":
            exp_date = (DT.date.today() + DT.timedelta(days=15)).strftime("%Y-%m-%d")
        elif exp_data == "30":
            exp_date = (DT.date.today() + DT.timedelta(days=30)).strftime("%Y-%m-%d")
        else:
            exp_date = "Lifetime"

        uuid = subprocess.check_output("cat /proc/sys/kernel/random/uuid", shell=True).decode("utf-8").strip()
        asu = f'''
        {{
            "v": "2",
            "ps": "{user}",
            "add": "{bug}",
            "port": "443",
            "id": "{uuid}",
            "aid": "0",
            "net": "ws",
            "sni": "{DOMAIN}",
            "path": "/xrayvws",
            "type": "none",
            "host": "{DOMAIN}",
            "tls": "tls"
        }}
        '''
        ask = f'''
        {{
            "v": "2",
            "ps": "{user}",
            "add": "{bug}",
            "port": "80",
            "id": "{uuid}",
            "aid": "0",
            "net": "ws",
            "path": "/xrayvws",
            "type": "none",
            "host": "{DOMAIN}",
            "tls": "none"
        }}
        '''
        puki = f'''
        {{
            "v": "2",
            "ps": "{user}",
            "add": "{bug}",
            "port": "443",
            "id": "{uuid}",
            "aid": "0",
            "net": "grpc",
            "path": "vmess-grpc",
            "type": "none",
            "host": "{DOMAIN}",
            "tls": "tls"
        }}
        '''

        # Konversi teks konfigurasi menjadi base64
        uncode = f'vmess://{base64.b64encode(asu.encode()).decode()}'
        memek= f'vmess://{base64.b64encode(ask.encode()).decode()}'
        pukimax = f'vmess://{base64.b64encode(puki.encode()).decode()}'

        cmd = f'sed -i "/#vmess$/a### {user} {exp_date}\\n}},{{\\"id\\": \\"{uuid}\\",\\"alterId\\": \\0\\,\\"email\\": \\"{user}\\"" /etc/xray/config.json'
        cmd2 = f'sed -i "/#vmessgrpc$/a### {user} {exp_date}\\n}},{{\\"id\\": \\"{uuid}\\",\\"alterId\\": \\0\\,\\"email\\": \\"{user}\\"" /etc/xray/config.json'
        nekat = f'{cmd} && {cmd2}'
        try:
            subprocess.check_output(nekat, shell=True)
        except subprocess.CalledProcessError:
            await event.respond("**Akun Tersedia!!**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp_data))
            msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ VMESS Account ⟩**
**━━━━━━━━━━━━━━━━**
**» Domain:** `{DOMAIN}`
**» Nama Akun:** `{user.strip()}`
**━━━━━━━━━━━━━━━━**
**» VMESS SSL:** `443`
**» VMESS SSL GRPC:** `443`
**» VMESS Non SSL:** `80`
**━━━━━━━━━━━━━━━━**
**⟨ Akun VMESS SSL BUG MODE BULAK BALIK ⟩**
`{uncode}`
**⟨ Akun VMESS GRPC SSL BUG MODE BULAK BALIK ⟩**
`{memek}`
**⟨ Akun VMESS NON SSL MODE BUG MODE BULAK BALIK ⟩**
`{pukimax}`
**━━━━━━━━━━━━━━━━**
**» 🗓         Masa Aktif Sampai Tanggal:** `{later}`
**» 🤖@Lihin929**
**━━━━━━━━━━━━━━━━**
"""
        inline = [
            [Button.inline("[ Menu ]","menu")],
            [Button.url("[ Contact ]", "t.me/lihin929")],
            [Button.url("[ Channel ]", "t.me/lihin929")]
        ]

        try:
            subprocess.check_output("systemctl restart xray", shell=True)
            subprocess.check_output("systemctl restart xray.service", shell=True)
        except subprocess.CalledProcessError:
            await event.respond("**Gagal Merestart Xray**")
        else:
            await event.respond(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await add_vmess_(event)
    else:
        await event.answer("Eh Lu Siapa Ha?", alert=True)

