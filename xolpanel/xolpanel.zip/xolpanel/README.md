# xolpanel
```
apt update && apt install wget -y && wget https://raw.githubusercontent.com/lihin929/xolpanel/master/xolpanel.sh && chmod +x xolpanel.sh && ./xolpanel.sh
```
