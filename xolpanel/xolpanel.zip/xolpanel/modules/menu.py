from xolpanel import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline("[ SSH Menu ]","ssh")],
        [Button.inline("[ Menu Vless ]","vless")],  # Menambahkan tombol Vless Menu
        [Button.inline("[ Menu Vmess ]","vmess")],  # Menambahkan tombol Vmess menu
        [Button.inline("[ Menu Trojan ]","trojan")],  # Menambahkan tombol button trojan
        [Button.url("[ Feedback ]","https://t.me/lihin929")],
        [Button.url("[ Telegram Group ]","https://t.me/lihin929")]
    ]
    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer("Eh Lu Siapa Ha?", alert=True)
        except:
            await event.reply("Eh Lu Siapa Ha?")
    elif val == "true":
        msg = """
━━━━━━━━━━━━━━━━
[Admin Panel Menu](https://i.ibb.co/RCf8yW1/Fm5-Mt55-WYAANw9n.jpg)
━━━━━━━━━━━━━━━━
**» 🤖Bot Version:** `v3.1`
**» 🤖Bot Source Code By:** `@givpn`
**» 🤖Bot Rombakan By:** '@lihin929'
━━━━━━━━━━━━━━━━
"""
        x = await event.edit(msg, buttons=inline)
        if not x:
            await event.reply(msg, buttons=inline)

