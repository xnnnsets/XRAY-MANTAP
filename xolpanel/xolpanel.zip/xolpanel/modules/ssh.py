from xolpanel import *

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
    async def ssh_(event):
        inline = [
            [Button.inline("[ Trial SSH ]", "trial-ssh")],
            [Button.inline("[ Create SSH ]", "create-ssh")],
            [Button.inline("[ Delete SSH ]", "delete-ssh")],
            [Button.inline("[ Check Login SSH ]", "login-ssh")],
            [Button.inline("[ Show All User SSH ]", "show-ssh")],
            [Button.inline("‹ Main Menu ›", "menu")]
        ]
        z = None
        try:
            z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        except requests.exceptions.ConnectionError as e:
            # Tangani kesalahan koneksi
            await event.edit("Failed to retrieve location information")
        msg = f"""
**━━━━━━━━━━━━━━━━**
[ ](https://i.ibb.co/RCf8yW1/Fm5-Mt55-WYAANw9n.jpg)
**⟨ SSH Menu ⟩**
**━━━━━━━━━━━━━━━━**
**» Service:** `SSH`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"] if z else "N/A"}`
**» Country:** `{z["country"] if z else "N/A"}`
**» 🤖@givpn**
**━━━━━━━━━━━━━━━━**
"""
        await event.edit(msg, buttons=inline)

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await ssh_(event)
    else:
        await event.answer("Eh Lu Siapa Ha?", alert=True)

