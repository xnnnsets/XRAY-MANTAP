from xolpanel import *

@bot.on(events.CallbackQuery(data=b'show-vless'))
async def show_vless(event):
	async def show_vless_(event):
		cmd = '''grep -E "^#& " "/etc/xray/config.json" | cut -d ' ' -f 2-3 | sort | uniq | nl -w1'''
		x = subprocess.check_output(cmd,shell=True).decode("ascii").split("\n")
		z = []
		for us in x:
			z.append("`"+us+"`")
		zx = "\n".join(z)
		await event.respond(f"""
**Showing All SSH User**

{zx}
`
**Total SSH Account:** `{str(len(z))}`
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await show_vless_(event)
	else:
		await event.answer("Eh Lu Siapa Ha?",alert=True)

