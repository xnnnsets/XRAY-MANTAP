from xolpanel import *

@bot.on(events.CallbackQuery(data=b'trial-trojan'))
async def trial_trojan(event):
    async def trial_trojan_(event):
        chat = event.chat_id  # Mendefinisikan chat di tingkat yang sesuai
        user = "trialX" + str(random.randint(100, 1000))
        
        async with bot.conversation(chat) as bug:
            await event.respond('**Masukan Bug Nya Mas:**')
            bug = bug.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            bug = (await bug).raw_text

        exp_data = "1"
        exp_date = None
        if exp_data == "1":
            exp_date = (DT.date.today() + DT.timedelta(days=1)).strftime("%Y-%m-%d")
        uuid = subprocess.check_output("cat /proc/sys/kernel/random/uuid", shell=True).decode("utf-8").strip()
        urlgrpc1 = f'trojan://{uuid}@{DOMAIN}:443?mode=gun&security=tls&type=grpc&serviceName=trojan-grpc&sni={bug}#{user}'
        urltls1 = f'trojan://{uuid}@{bug}:443?path=/xraytrojanws&security=tls&host={DOMAIN}&type=ws&sni={DOMAIN}#{user}'
        urlnone1 = f'trojan://{uuid}@{bug}:80?path=/xraytrojanws&security=none&host={DOMAIN}&type=ws#{user}'
        urlgrpc = f'trojan://{uuid}@{bug}:443?mode=gun&security=tls&type=grpc&serviceName=trojan-grpc&sni={DOMAIN}#{user}'
        urltls = f'trojan://{uuid}@{DOMAIN}:443?path=/xraytrojanws&security=tls&host={bug}&type=ws&sni={bug}#{user}'
        urlnone = f'trojan://{uuid}@{DOMAIN}:80?path=/xraytrojanws&security=none&host={bug}&type=ws#{user}'

        cmd = f'sed -i "/#trojanws$/a#! {user} {exp_date}\\n}},{{\\"password\\": \\"{uuid}\\",\\"email\\": \\"{user}\\"" /etc/xray/config.json'
        cmd2 = f'sed -i "/#trojangrpc$/a#! {user} {exp_date}\\n}},{{\\"password\\": \\"{uuid}\\",\\"email\\": \\"{user}\\"" /etc/xray/config.json'
        pukimekas = f'{cmd} && {cmd2}'

        try:
            subprocess.check_output(pukimekas, shell=True)
        except subprocess.CalledProcessError:
            await event.respond("**Akun Tersedia!!**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp_data))
            msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ TRIAL TROJAN Account ⟩**
**━━━━━━━━━━━━━━━━**
**» Domain:** `{DOMAIN}`
**» Nama Akun:** `{user.strip()}`
**━━━━━━━━━━━━━━━━**
**» TROJAN SSL:** `443`
**» TROJAN SSL GRPC:** `443`
**» TROJAN Non SSL:** `80`
**━━━━━━━━━━━━━━━━**
**⟨ Akun TROJAN SSL BUG MODE BULAK BALIK  ⟩**
`{urltls1}`
**⟨ Akun TROJAN GRPC SSL BUG MODE BULAK BALIK  ⟩**
`{urlgrpc}`
**⟨ Akun TROJAN NON SSL MODE BULAK BALIK ⟩**
`{urlnone1}`
**━━━━━━━━━━━━━━━━**
**⟨ Akun TROJAN SSL BUG MODE NORMAL  ⟩**
`{urltls}`
**⟨ Akun TROJAN GRPC SSL BUG MODE MORMAL ⟩**
`{urlgrpc}`
**⟨ Akun TROJAN NON SSL MODE BUG NORMAL ⟩**
`{urlnone}`
**━━━━━━━━━━━━━━━━**
**» 🗓        Masa Aktif Sampai Tanggal:** `{later}`
**» 🤖@Lihin929**
**━━━━━━━━━━━━━━━━**
"""
            inline = [
                [Button.inline("[ Menu ]", "menu")],
                [Button.url("[ Contact ]", "t.me/lihin929")],
                [Button.url("[ Channel ]", "t.me/lihin929")]
            ]

            try:
                subprocess.check_output("systemctl restart xray", shell=True)
                subprocess.check_output("systemctl restart xray.service", shell=True)
            except:
                await event.respond("**Failed to restart Xray**")
            else:
                await event.respond(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await trial_trojan_(event)
    else:
        await event.answer("Eh Lu Siapa Ha?", alert=True)

