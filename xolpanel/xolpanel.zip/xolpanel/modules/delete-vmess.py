from xolpanel import *
  
@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
    async def delete_vmess_(event):
        cmd = 'grep -c -E "^### " "/etc/xray/config.json"'
        num_accounts = 0

        try:
            num_accounts = int(subprocess.check_output(cmd, shell=True))
        except subprocess.CalledProcessError:
            pass

        if num_accounts == 0:
            inline = [
                [Button.inline("[ Kembali Ke Menu ]", "menu")]
            ]
            await event.respond("**Akun Tidak Tersedia**", buttons=inline)
            return

        async with bot.conversation(chat) as user:
            await event.respond("**Nama Yang Terdaftar Di Akun Vmess:**")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text

        try:
            subprocess.check_output(f'sed -i "/^### {user}/,/^}},{{/d" /etc/xray/config.json', shell=True)
            await event.respond(f"**Berhasil Terhapus Akun: ** `{user}`")

            # Tambahkan perintah restart xray di sini
            try:
                subprocess.check_output('systemctl restart xray', shell=True)
                subprocess.check_output('systemctl restart xray.service', shell=True)
            except subprocess.CalledProcessError:
                await event.respond("**Gagal Merestart Xray**")

        except:
            await event.respond(f"**Gagal Menghapus Akun: ** `{user}`")

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))

    if a == "true":
        await delete_vmess_(event)
    else:
        await event.answer("Eh Lo Siapa Ha?", alert=True)
