from xolpanel import *
import base64

@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
    async def trial_vmess_(event):
        user = "trialX" + str(random.randint(100, 1000))
        async with bot.conversation(chat) as bug:
            await event.respond('**Masukan Bug Nya Mas:**')
            bug = bug.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            bug = (await bug).raw_text
        exp_data = "1"
        exp_date = None
        if exp_data == "1":
            exp_date = (DT.date.today() + DT.timedelta(days=1)).strftime("%Y-%m-%d")
        uuid = subprocess.check_output("cat /proc/sys/kernel/random/uuid", shell=True).decode("utf-8").strip()
        asu = f'''
        {{
            "v": "2",
            "ps": "{user}",
            "add": "{bug}",
            "port": "443",
            "id": "{uuid}",
            "aid": "0",
            "net": "ws",
            "sni": "{DOMAIN}",
            "path": "/xrayvws",
            "type": "none",
            "host": "{DOMAIN}",
            "tls": "tls"
        }}
        '''
        ask = f'''
        {{
            "v": "2",
            "ps": "{user}",
            "add": "{bug}",
            "port": "80",
            "id": "{uuid}",
            "aid": "0",
            "net": "ws",
            "path": "/xrayvws",
            "type": "none",
            "host": "{DOMAIN}",
            "tls": "none"
        }}
        '''
        puki = f'''
        {{
            "v": "2",
            "ps": "{user}",
            "add": "{bug}",
            "port": "443",
            "id": "{uuid}",
            "aid": "0",
            "net": "grpc",
            "path": "vmess-grpc",
            "type": "none",
            "host": "{DOMAIN}",
            "tls": "tls"
        }}
        '''

        # Konversi teks konfigurasi menjadi base64
        uncode = f'vmess://{base64.b64encode(asu.encode()).decode()}'
        memek= f'vmess://{base64.b64encode(ask.encode()).decode()}'
        pukimax = f'vmess://{base64.b64encode(puki.encode()).decode()}'

        cmd = f'sed -i "/#vmess$/a### {user} {exp_date}\\n}},{{\\"id\\": \\"{uuid}\\",\\"alterId\\": \\0\\,\\"email\\": \\"{user}\\"" /etc/xray/config.json'
        cmd2 = f'sed -i "/#vmessgrpc$/a### {user} {exp_date}\\n}},{{\\"id\\": \\"{uuid}\\",\\"alterId\\": \\0\\,\\"email\\": \\"{user}\\"" /etc/xray/config.json'
        nekat = f'{cmd} && {cmd2}'
        try:
            subprocess.check_output(nekat, shell=True)
        except subprocess.CalledProcessError:
            await event.respond("**Akun Tersedia!!**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp_data))
            msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ VMESS Account TRIAL! ⟩**
**━━━━━━━━━━━━━━━━**
**» Domain:** `{DOMAIN}`
**» Nama Akun:** `{user.strip()}`
**━━━━━━━━━━━━━━━━**
**» VMESS SSL:** `443`
**» VMESS SSL GRPC:** `443`
**» VMESS Non SSL:** `80`
**━━━━━━━━━━━━━━━━**
**⟨ Akun VMESS SSL BUG MODE BULAK BALIK ⟩**
`{uncode}`
**⟨ Akun VMESS GRPC SSL BUG MODE BULAK BALIK ⟩**
`{memek}`
**⟨ Akun VMESS NON SSL MODE BUG MODE BULAK BALIK ⟩**
`{pukimax}`
**━━━━━━━━━━━━━━━━**
**» 🗓          Masa Aktif Sampai Tanggal:** `{later}`
**» 🤖@Lihin929**
**━━━━━━━━━━━━━━━━**
"""
        inline = [
            [Button.inline("[ Menu ]","menu")],
            [Button.url("[ Contact ]", "t.me/lihin929")],
            [Button.url("[ Channel ]", "t.me/lihin929")]
        ]

        try:
            subprocess.check_output("systemctl restart xray", shell=True)
            subprocess.check_output("systemctl restart xray.service", shell=True)
        except subprocess.CalledProcessError:
            await event.respond("**Gagal Merestart Xray**")
        else:
            await event.respond(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await trial_vmess_(event)
    else:
        await event.answer("Eh Lo Siapa Anjay?", alert=True)

