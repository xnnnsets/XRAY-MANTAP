from xolpanel import *

@bot.on(events.CallbackQuery(data=b'add-vless'))
async def add_vless(event):
    async def add_vless_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Masukan Nama Akun Vless Lo:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        async with bot.conversation(chat) as bug:
            await event.respond('**Masukan Bug Nya Mas:**')
            bug = bug.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            bug = (await bug).raw_text
        async with bot.conversation(chat) as exp:
            await event.respond("**Anda Mau Membuat Akun Berapa Hari**", buttons=[
                [Button.inline("• 7 Day •", "7")],
                [Button.inline("• 15 Day •", "15")],
                [Button.inline("• 30 Day •", "30")],
                [Button.inline("• Lifetime •", "500")]
            ])
            exp = exp.wait_event(events.CallbackQuery)
            exp_data = (await exp).data.decode("ascii")

        exp_date = None
        if exp_data == "7":
            exp_date = (DT.date.today() + DT.timedelta(days=7)).strftime("%Y-%m-%d")
        elif exp_data == "15":
            exp_date = (DT.date.today() + DT.timedelta(days=15)).strftime("%Y-%m-%d")
        elif exp_data == "30":
            exp_date = (DT.date.today() + DT.timedelta(days=30)).strftime("%Y-%m-%d")
        else:
            exp_date = "Lifetime"

        uuid = subprocess.check_output("cat /proc/sys/kernel/random/uuid", shell=True).decode("utf-8").strip()
        urlgrpc = f'vless://{uuid}@{bug}:443?mode=gun&security=tls&encryption=none&type=grpc&serviceName=vless-grpc&sni={DOMAIN}#{user}'
        urltls = f'vless://{uuid}@{bug}:443?path=/xrayws&security=tls&sni={DOMAIN}&host={DOMAIN}encryption=none&type=ws#{user}'
        urlnone = f'vless://{uuid}@{bug}:80?path=/xrayws&security=none&host={DOMAIN}&encryption=none&type=ws#{user}'

        cmd = f'sed -i "/#vlessgrpc$/a#& {user} {exp_date}\\n}},{{\\"id\\": \\"{uuid}\\",\\"email\\": \\"{user}\\"" /etc/xray/config.json'
        cmd2 = f'sed -i "/#vless$/a#& {user} {exp_date}\\n}},{{\\"id\\": \\"{uuid}\\",\\"email\\": \\"{user}\\"" /etc/xray/config.json'
        kombinasi = f'{cmd} && {cmd2}'

        try:
            subprocess.check_output(kombinasi, shell=True)
        except subprocess.CalledProcessError:
            await event.respond("**Akun Tersedia!!**")

        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp_data))
            msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ VLESS Account ⟩**
**━━━━━━━━━━━━━━━━**
**» Domain:** `{DOMAIN}`
**» Nama Akun:** `{user.strip()}`
**━━━━━━━━━━━━━━━━**
**» VLESS SSL:** `443`
**» VLESS SSL GRPC:** `443`
**» VLESS Non SSL:** `80`
**━━━━━━━━━━━━━━━━**
**⟨ Akun VLESS SSL BUG MODE BULAK BALIK  ⟩**
`{urltls}`
**⟨ Akun VLESS GRPC SSL BUG MODE BULAK BALIK  ⟩**
`{urlgrpc}`
**⟨ Akun VLESS NON SSL MODE BULAK BALIK ⟩**
`{urlnone}`
**━━━━━━━━━━━━━━━━**
**» 🗓       Masa Aktif Sampai Tanggal:** `{later}`
**» 🤖@Lihin929**
**━━━━━━━━━━━━━━━━**
"""
        inline = [
            [Button.inline("[ Menu ]","menu")],
            [Button.url("[ Contact ]", "t.me/lihin929")],
            [Button.url("[ Channel ]", "t.me/lihin929")]
        ]

        try:
            subprocess.check_output("systemctl restart xray", shell=True)
            subprocess.check_output("systemctl restart xray.service", shell=True)
        except:
            await event.respond("**Failed to restart Xray**")
        else:
            await event.respond(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await add_vless_(event)
    else:
        await event.answer("Eh Lu Siapa Ha?", alert=True)
